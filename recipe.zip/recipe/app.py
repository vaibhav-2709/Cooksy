from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL
import requests
import os
from werkzeug.utils import secure_filename
app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root' 
app.config['MYSQL_PASSWORD'] = '' 
app.config['MYSQL_DB'] = 'culinary_db' 
app.config['MYSQL_PORT'] = 3307
app.secret_key = 'your_secret_key'
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
mysql = MySQL(app)
EDAMAM_API_KEY="eec7d7aad350e97f7abbe184d5710662"
RECIPE_API_KEY = "99fecb829e204c9ebc0683f9623b7e9a"
RECIPE_SEARCH_API_URL = "https://api.spoonacular.com/recipes/complexSearch"
RECIPE_INFO_API_URL = "https://api.spoonacular.com/recipes/{id}/information"
RANDOM_RECIPE_API_URL = "https://api.spoonacular.com/recipes/random"
GOOGLE_TRANSLATE_API_KEY = "AIzaSyCt2X9Zj4l8ZjS1nq77tjfpjJ65KPX_ar0"
@app.route('/')
def landing_page():
    return render_template('landing_page.html')
@app.route('/add', methods=['GET', 'POST'])
def add_recipe():
    if request.method == 'POST':
        title = request.form['title']
        ingredients = request.form['ingredients']
        instructions = request.form['instructions']
        user_id = session.get('user_id')
        image = request.files['image']
        if image:
            filename = secure_filename(image.filename)
            image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        cur = mysql.connection.cursor()
        cur.execute(
            "INSERT INTO dishes (title, ingredients, instructions, user_id, image) VALUES (%s, %s, %s, %s, %s)",
            (title, ingredients, instructions, user_id, filename) 
        )
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('index'))
    return render_template('add_recipe.html')
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    user_id = session.get('user_id')
    cur = mysql.connection.cursor()
    cur.execute("SELECT username, profile_image FROM accounts WHERE id = %s", (user_id,))
    user = cur.fetchone()
    cur.close()
    if request.method == 'POST':
        if 'profile_image' in request.files:
            profile_image = request.files['profile_image']
            if profile_image:
                profile_image.save(f'static/uploads/{profile_image.filename}') 
                cur = mysql.connection.cursor()
                cur.execute("UPDATE accounts SET profile_image = %s WHERE id = %s", (profile_image.filename, user_id))
                mysql.connection.commit()
                cur.close()
                flash('Profile image updated successfully!')
                return redirect(url_for('profile'))
    return render_template('profile.html', user=user)
@app.route('/delete_recipe/<int:id>', methods=['POST'])
def delete_recipe(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM dishes WHERE id = %s", (id,))
    mysql.connection.commit()
    cur.close()
    flash('Recipe deleted successfully!')
    return redirect(url_for('index'))
@app.route('/index')
def index():
    user_id = session.get('user_id')
    cur = mysql.connection.cursor()
    cur.execute("SELECT profile_image FROM accounts WHERE id = %s", (user_id,))
    user = cur.fetchone()
    cur.execute("SELECT * FROM dishes WHERE user_id = %s", (user_id,)) 
    recipes = cur.fetchall()
    cur.close()
    profile_image = user[0] if user else None 
    return render_template('index.html', recipes=recipes, profile_image=profile_image)
@app.route('/search', methods=['GET', 'POST'])
def search_recipe():
    if request.method == 'POST':
        query = request.form['query']
        response = requests.get(RECIPE_SEARCH_API_URL, params={"apiKey": RECIPE_API_KEY, "query": query})
        recipes = response.json().get('results', [])
        return render_template('search_recipe.html', recipes=recipes, query=query)
    return render_template('search_recipe.html', recipes=[], query='')
@app.route('/translate', methods=['GET', 'POST'])
def translate_recipe():
    translation = ''
    error = ''
    if request.method == 'POST':
        text_to_translate = request.form['text']
        target_language = request.form['language']
        response = requests.get(
            "https://translation.googleapis.com/language/translate/v2",
            params={"q": text_to_translate, "target": target_language, "key": GOOGLE_TRANSLATE_API_KEY}
        )
        if response.status_code == 200:
            translation = response.json().get('data', {}).get('translations', [{}])[0].get('translatedText', '')
            if not translation:
                error = 'Translation failed. Please check the input text and target language.'
        else:
            error = f'Error: {response.status_code} - {response.json().get("error", {}).get("message", "Unknown error occurred")}'
    return render_template('translate.html', translation=translation, error=error)
@app.route('/recipe/<int:id>')
def recipe_details(id):
    response = requests.get(RECIPE_INFO_API_URL.format(id=id), params={"apiKey": RECIPE_API_KEY})
    if response.status_code == 200:
        recipe = response.json()
    else:
        flash('Recipe not found.')
        return redirect(url_for('index'))
    return render_template('recipe_details.html', recipe=recipe)
@app.route('/random')
def random_recipe():
    response = requests.get(RANDOM_RECIPE_API_URL, params={"apiKey": RECIPE_API_KEY})
    recipe = response.json().get('recipes', [])[0]
    return render_template('random_recipe.html', recipe=recipe)
@app.route('/save_favorite', methods=['POST'])
def save_favorite():
    user_id = session['user_id'] 
    dish_id = request.form['dish_id'] 
    title = request.form['title'] 
    ingredients = request.form['ingredients'] 
    instructions = request.form['instructions']
    image = request.form['image']
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO user_favorites (account_id, dish_id, title, ingredients, instructions, image) VALUES (%s, %s, %s, %s, %s, %s)',
                (user_id, dish_id, title, ingredients, instructions, image))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('favorites'))
@app.route('/favorite_recipe/<int:id>')
def favorite_recipe_details(id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM user_favorites WHERE id = %s", (id,))
    recipe = cur.fetchone()
    cur.close()
    if recipe:
        return render_template('favorite_recipe_details.html', recipe=recipe)
    else:
        flash('Recipe not found.')
        return redirect(url_for('favorites'))
@app.route('/favorites')
def favorites():
    user_id = session['user_id']
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM user_favorites WHERE account_id = %s', (user_id,)) 
    favorites = cur.fetchall()
    cur.close()
    return render_template('favorites.html', favorites=favorites)
@app.route('/delete_favorite/<int:id>', methods=['POST'])
def delete_favorite(id):
    cur = mysql.connection.cursor()
    cur.execute('DELETE FROM user_favorites WHERE id = %s', (id,)) 
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('favorites'))
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO accounts (username, password) VALUES (%s, %s)", (username, password))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('login'))
    return render_template('register.html')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM accounts WHERE username = %s AND password = %s", (username, password))
        user = cur.fetchone()
        cur.close()
        if user:
            session['user_id'] = user[0] 
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')
@app.route('/logout')
def logout():
    session.pop('user_id', None) 
    return redirect(url_for('landing_page'))
if __name__ == '_main_':
    app.run(debug=True)